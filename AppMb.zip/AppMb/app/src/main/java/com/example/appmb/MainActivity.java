package com.example.appmb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.AnalogClock;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      //  setContentView(R.layout.activity_main);  //Unión entre vista y controlador

        TextView etiquetaT = new TextView(this);
        etiquetaT.setText("Titulua");

        TextView etiquetaS = new TextView(this);
        etiquetaS.setText("Subtítulo");

        TextView etiquetaG = new TextView(this);
        etiquetaG.setText("Galdera");

        CheckBox auk1etiqueta= new CheckBox(this);
        auk1etiqueta.setText("Aukera 1");

        CheckBox auk2etiqueta= new CheckBox(this);
        auk1etiqueta.setText("Aukera 2");

        //LinearLayout------------------
        LinearLayout ellayout = new LinearLayout(this);
        ellayout.setOrientation(LinearLayout.HORIZONTAL);
        ellayout.addView(etiquetaT);
        ellayout.addView(etiquetaS);
        ellayout.addView(etiquetaG);
        ellayout.addView(auk1etiqueta);
       // ellayout.removeView(etiqueta);
        setContentView(ellayout);
        //---------------------------

        // TableLayout-------------
        TableLayout tablayout= new TableLayout(this);
        tablayout.setOrientation(LinearLayout.VERTICAL);
        tablayout.addView(etiquetaT);
        tablayout.addView(etiquetaS);
        tablayout.addView(etiquetaG);
       // setContentView(tablayout);
    }
}